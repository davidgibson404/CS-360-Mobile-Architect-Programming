package com.example.david_gibson_weight_tracker;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EditWeightDialogFragment extends DialogFragment {

    private final String existingDate;
    private final float existingWeight;
    private final long recordId;
    private DBHelper dbHelper;

    // Constructor to initialize the dialog fragment
    public EditWeightDialogFragment(long recordId, String date, float weight) {
        this.recordId = recordId;
        this.existingDate = date;
        this.existingWeight = weight;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Initialize the database helper
        dbHelper = new DBHelper(getActivity());

        View view = getLayoutInflater().inflate(R.layout.dialog_edit_weight, null);
        EditText editDate = view.findViewById(R.id.editDialogDate);
        EditText editWeight = view.findViewById(R.id.editDialogWeight);

        editDate.setText(existingDate);
        editWeight.setText(String.valueOf(existingWeight));

        // Build and return the dialog
        return new AlertDialog.Builder(getActivity())
                .setView(view)
                .setPositiveButton("Save", (dialog, id) -> {
                    String date = editDate.getText().toString();
                    String weightString = editWeight.getText().toString();

                    // Validate the date format
                    if (!isValidDate(date)) {
                        Toast.makeText(getContext(), "Date must be in dd/mm/yy format", Toast.LENGTH_SHORT).show();
                        return;  // Prevent saving if date is invalid
                    }

                    // Proceeds with saving the record if the record ID is valid
                    if (recordId > 0) {
                        try {
                            float weight = Float.parseFloat(weightString);
                            saveWeightRecord(recordId, date, weight);

                            if (getActivity() instanceof MainActivity) {
                                ((MainActivity) getActivity()).updateWeightRecord(new WeightRecord(recordId, date, weight));
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(getContext(), "Invalid weight format", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss())
                .create();
    }

    // Updates the weight record in the database with the new values.
    private void saveWeightRecord(long id, String date, float weight) {
        dbHelper.updateWeightRecord(id, date, weight);

    }
    // Validates if the date is in the correct dd/mm/yy format.
    private boolean isValidDate(String date) {
        // Regular expression for validating dd/mm/yy format
        String datePattern = "^\\d{2}/\\d{2}/\\d{2}$";
        return date.matches(datePattern);
    }
}
