package com.example.david_gibson_weight_tracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private final List<WeightRecord> weightList = new ArrayList<>();
    private DBHelper dbHelper;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        // Initialize the database helper
        dbHelper = new DBHelper(this);

        // Set up the RecyclerView with a LinearLayoutManager and the custom adapter
        recyclerView = findViewById(R.id.containerRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new WeightAdapter(this, weightList, dbHelper);
        recyclerView.setAdapter(adapter);

        // Load weight records from the database when the activity is created
        loadWeightRecords();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                return true;
            } else if (id == R.id.nav_sms) {
                startActivity(new Intent(MainActivity.this, SMSActivity.class));
                return true;
            } else if (id == R.id.nav_data_grid) {
                openAddWeightDialog();
                return true;
            } else if (id == R.id.nav_logoff) {
                logOff();
                return true;
            }

            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadWeightRecords(); // Latest data is always shown when returning to the activity
    }
    // Reload data after adding a weight
    void openAddWeightDialog() {
        try {
            AddWeightDialogFragment dialog = new AddWeightDialogFragment();
            dialog.setOnDismissListener(dialogInterface -> loadWeightRecords());
            dialog.show(getSupportFragmentManager(), "AddWeightDialogFragment");
        } catch (Exception e) {
            Log.e(TAG, "Error opening AddWeightDialog", e);
        }
    }
    // Adds a new weight record to the list and updates the RecyclerView.
    public void addWeightRecord(WeightRecord weightRecord) {
        weightList.add(weightRecord);
        adapter.notifyItemInserted(weightList.size() - 1);
        recyclerView.scrollToPosition(weightList.size() - 1); // Scroll to the new item
    }

    // Updates an existing weight record in the list and notifies the adapter.
    public void updateWeightRecord(WeightRecord updatedRecord) {
        for (int i = 0; i < weightList.size(); i++) {
            if (weightList.get(i).getId() == updatedRecord.getId()) {
                weightList.set(i, updatedRecord);
                adapter.notifyItemChanged(i);  // Correct variable is 'adapter'
                break;
            }
        }
    }

    void logOff() {
        try {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error logging off", e);
        }
    }
    // Loads weight records from the database and updates the RecyclerView.
    private void loadWeightRecords() {
        try {
            weightList.clear();  // Clear the current list
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM weights", null);

            int idIndex = cursor.getColumnIndex("id");
            int dateIndex = cursor.getColumnIndex("date");
            int weightIndex = cursor.getColumnIndex("weight");

            if (idIndex == -1 || dateIndex == -1 || weightIndex == -1) {
                Log.e(TAG, "Invalid column index.");
                return;
            }

            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(idIndex);
                    String date = cursor.getString(dateIndex);
                    float weight = cursor.getFloat(weightIndex);
                    weightList.add(new WeightRecord(id, date, weight));
                } while (cursor.moveToNext());
            }

            cursor.close();
            adapter.notifyDataSetChanged(); // Notify the adapter that the data has changed

        } catch (Exception e) {
            Log.e(TAG, "Error loading weight records", e);
        }
    }
}