package com.example.david_gibson_weight_tracker;

public class WeightRecord {
    private long id;
    private final String date;
    private final float weight;

    public WeightRecord(long id, String date, float weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }


}

