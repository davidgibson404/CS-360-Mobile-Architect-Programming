package com.example.david_gibson_weight_tracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;
    private TextView permissionStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button requestPermissionButton = findViewById(R.id.requestPermissionButton);
        permissionStatusTextView = findViewById(R.id.permissionStatusTextView);

        // Set up click listener for requesting SMS permission
        requestPermissionButton.setOnClickListener(view -> requestSmsPermission());

        // Update the permission status when the activity is created
        updatePermissionStatus();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnItemSelectedListener(this::onNavigationItemSelected);
    }

    // Requests the SMS permission if not already granted.
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSMSNotification();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Check if the SMS permission was granted or denied
        if (requestCode == SMS_PERMISSION_CODE) {
            // Permission granted, send the SMS notification
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMSNotification();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
        updatePermissionStatus();
    }

    private void sendSMSNotification() {
        Toast.makeText(this, "SMS Notification Sent", Toast.LENGTH_SHORT).show();
    }

    //Updates the TextView to show whether the SMS permission has been granted or denied.
    private void updatePermissionStatus() {
        permissionStatusTextView.setText(ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED ?
                R.string.permission_granted : R.string.permission_denied);
    }

    private boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            startActivity(new Intent(SMSActivity.this, MainActivity.class));
            return true;
        } else if (id == R.id.nav_sms) {
            // Already on SMS screen, no action needed
            return true;
        } else if (id == R.id.nav_data_grid) {
            startActivity(new Intent(SMSActivity.this, MainActivity.class));
            return true;
        } else if (id == R.id.nav_logoff) {
            startActivity(new Intent(SMSActivity.this, LoginActivity.class));
            finish();
            return true;
        }

        return false;
    }
}
