package com.example.david_gibson_weight_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    // Database name and version constants
    private static final String DATABASE_NAME = "userdb";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "weights";

    // Constructor creates an instance of DBHelper
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create the 'weights' table
        String createWeightsTable = "CREATE TABLE IF NOT EXISTS weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "weight REAL)";
        db.execSQL(createWeightsTable);

        // SQL statement to create the 'users' table
        String createUsersTable = "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "password TEXT)";
        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        onCreate(db);
    }

    // Deletes a weight record from the database by its ID.
    public void deleteWeightRecord(long id) {
        if (id <= 0) return;

        try (SQLiteDatabase db = this.getWritableDatabase()) {
            db.delete(TABLE_NAME, "id = ?", new String[]{String.valueOf(id)});
        }
    }

    // Updates a weight record in the database with new date and weight values.
    public void updateWeightRecord(long id, String date, float weight) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("weight", weight);

        try (SQLiteDatabase db = this.getWritableDatabase()) {
            db.update(TABLE_NAME, contentValues, "id = ?", new String[]{String.valueOf(id)});
        }
    }
}