package com.example.david_gibson_weight_tracker;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class AddWeightDialogFragment extends DialogFragment {
    private OnDismissListener onDismissListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Create an AlertDialog builder and set up the view for the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_add_weight, null);

        // Initialize EditText fields for date and weight input
        EditText dateEditText = view.findViewById(R.id.editDialogDate);
        EditText weightEditText = view.findViewById(R.id.editDialogWeight);

        // Set up the dialog with Save and Cancel buttons
        builder.setView(view)
                .setTitle("Add Weight")
                .setPositiveButton("Save", (dialog, id) -> {
                    String date = dateEditText.getText().toString();
                    String weightString = weightEditText.getText().toString();

                    if (date.isEmpty()) {
                        Toast.makeText(getContext(), "Please enter a date", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!isValidDate(date)) {
                        Toast.makeText(getContext(), "Date must be in dd/mm/yy format", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (weightString.isEmpty()) {
                        Toast.makeText(getContext(), "Please enter a weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        float weight = Float.parseFloat(weightString);
                        saveWeightRecord(date, weight);

                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).addWeightRecord(new WeightRecord(id, date, weight));
                        }
                    } catch (NumberFormatException e) {
                        // Handle invalid weight format input
                        Toast.makeText(getContext(), "Invalid weight format", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

        return builder.create();
    }

    private boolean isValidDate(String date) {
        // Expression for validating dd/mm/yy format
        String datePattern = "^\\d{2}/\\d{2}/\\d{2}$";
        return date.matches(datePattern);
    }
    private void saveWeightRecord(String date, float weight) {
        // Get a writable instance of the database and insert the new weight record
        SQLiteDatabase db = new DBHelper(getContext()).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);
        db.insert("weights", null, values);  // Insert into database
        db.close();
    }

    @Override
    // Notify the listener (if any) that the dialog was dismissed
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        if (onDismissListener != null) {
            onDismissListener.onDismiss(dialog);
        }
    }

    public void setOnDismissListener(OnDismissListener listener) {
        this.onDismissListener = listener;
    }

    public interface OnDismissListener {
        void onDismiss(DialogInterface dialog);
    }
}