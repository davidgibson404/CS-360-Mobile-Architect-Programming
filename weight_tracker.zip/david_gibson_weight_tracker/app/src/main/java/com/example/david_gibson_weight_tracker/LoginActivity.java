package com.example.david_gibson_weight_tracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUserName, editPassword;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize EditText fields for username and password
        editUserName = findViewById(R.id.editUserName);
        editPassword = findViewById(R.id.editPassword);

        // Initialize the database helper and get a writable database instance
        DBHelper dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();

        findViewById(R.id.btnLogIn).setOnClickListener(view -> loginUser());
        findViewById(R.id.btnNewAccount).setOnClickListener(view -> registerUser());
    }

    private void loginUser() {
        // Get the username and password input
        String username = editUserName.getText().toString();
        String password = editPassword.getText().toString();

        // Search the database to find a user with the provided username and password
        try (Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password})) {
            if (cursor.moveToFirst()) {
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Handles user registration by inserting a new record into the database
    private void registerUser() {
        String username = editUserName.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill out both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try (Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=?", new String[]{username})) {
            if (cursor.moveToFirst()) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long newRowId = db.insert("users", null, values);
        Toast.makeText(this, newRowId != -1 ? "Account created successfully" : "Error creating account", Toast.LENGTH_SHORT).show();
    }
}

