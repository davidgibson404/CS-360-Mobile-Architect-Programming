package com.example.david_gibson_weight_tracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final List<WeightRecord> weightList;
    private final DBHelper dbHelper;
    private final Context context;  // Add this line

    // Constructor to initialize the adapter with context, weight list, and DBHelper
    public WeightAdapter(Context context, List<WeightRecord> weightList, DBHelper dbHelper) {  // Modify constructor
        this.context = context;  // Initialize context
        this.weightList = weightList;
        this.dbHelper = dbHelper;
    }

    // Removes a weight record from the list and database.
    public void removeItem(int position) {
        if (position < 0 || position >= weightList.size()) return;

        long recordId = weightList.get(position).getId();
        if (recordId > 0) {
            dbHelper.deleteWeightRecord(recordId);
            weightList.remove(position);
            notifyItemRemoved(position);
        }
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item_grid, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        // Bind the data from the weight record to the ViewHolder
        WeightRecord record = weightList.get(position);
        holder.dateTextView.setText(record.getDate());
        holder.weightTextView.setText(String.valueOf(record.getWeight()));

        // Delete button click listener
        holder.deleteButton.setOnClickListener(v -> removeItem(position));

        // Edit button click listener
        holder.editButton.setOnClickListener(v -> {
            if (context instanceof FragmentActivity) {
                FragmentManager fragmentManager = ((FragmentActivity) context).getSupportFragmentManager();
                new EditWeightDialogFragment(record.getId(), record.getDate(), record.getWeight())
                        .show(fragmentManager, "EditWeightDialogFragment");
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // ViewHolder class to hold the views for each item in the RecyclerView
    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        ImageButton deleteButton, editButton;

        WeightViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.textViewDate);
            weightTextView = itemView.findViewById(R.id.textViewWeightAmount);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
}
